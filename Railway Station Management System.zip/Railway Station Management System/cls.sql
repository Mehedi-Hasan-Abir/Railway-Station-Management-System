set lines 350;
set trimout on;
set tab off;

clear screen;