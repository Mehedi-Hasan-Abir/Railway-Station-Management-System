clear screen;

drop table train cascade constraints;
drop table station cascade constraints;
drop table passenger cascade constraints;
drop table troute cascade constraints;
drop table ticket cascade constraints;
drop table booking cascade constraints;