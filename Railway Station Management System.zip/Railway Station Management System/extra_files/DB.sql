clear screen;

drop table train cascade constraints;
drop table station cascade constraints;
drop table passenger cascade constraints;
drop table troute cascade constraints;
drop table ticket cascade constraints;
drop table booking cascade constraints;

create table train(
	tid int,
	tname varchar2(20),
	source varchar2(20),
	destination varchar2(20),
	seats int,
	primary key(tid)
);

create table station(
	stid int,
	stname varchar2(20),
	primary key(stid)
);

create table passenger(
	pid int,
	pname varchar2(20),
	gender varchar2(20),
	age int,
	city varchar2(20),
	primary key(pid)
);

create table troute(
	tid int,
	stid int,
	arrival date,
	departure date,
	foreign key(tid) references train(tid),
	foreign key(stid) references station(stid)
);

create table ticket(
	ticketid int,
	tid int,
	availability varchar2(20),
	class varchar2(20),
	source varchar2(20),
	dest varchar2(20),
	fare int,
	departure_time date,
	count int,
	primary key(ticketid),
	foreign key(tid) references train(tid)
);

create table booking(
	bid int,
	pid int, 
	ticketid int,
	seat_num int,
	seat_type varchar2(20),
	booking_status varchar2(20),
	location varchar2(20),
	primary key(bid),
	foreign key(pid) references passenger(pid),
	foreign key(ticketid) references ticket(ticketid)
);

insert into train(tid, tname, source, destination, seats)
	values(1, 'Subarna Express',  'Chittagong', 'Dhaka', 200);
	
commit;

select * from train;
select * from station;
select * from passenger;
select * from troute;
select * from ticket;
select * from booking;