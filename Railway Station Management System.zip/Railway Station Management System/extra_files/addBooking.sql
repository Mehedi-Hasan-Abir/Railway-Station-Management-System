set serveroutput on;
set verify off;

declare 
	pname passenger.pname%type := '&Passenger_name';
	gender passenger.gender%type := '&gender';
	age passenger.age%type := &age;
	city passenger.city%type := '&city';
	src train.source%type := '&Source';
	des train.destination%type := '&Destination';
	count_  ticket.count_%type := &count;

begin
	addBooking(pname,gender,age,city,src,des,count_);
end;
/