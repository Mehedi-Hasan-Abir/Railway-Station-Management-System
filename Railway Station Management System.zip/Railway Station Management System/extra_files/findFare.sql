set serveroutput on;
set verify off;

declare
	train_name train.tname%type := '&train_name';
	num varchar2(30);

begin
	findFareofTrain(train_name);
end;
/