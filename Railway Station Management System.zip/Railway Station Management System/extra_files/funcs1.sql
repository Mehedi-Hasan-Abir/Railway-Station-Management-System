-- FUNC 1
create or replace function bookTicket(pid in number, tktid in number, stype in varchar2, location in varchar2)
	return varchar2
	is
	
tkt_status varchar2(30);
cnt number;
begin
	select status_,count_ into tkt_status,cnt from ticket where ticketid = tktid; 
	
	if tkt_status = 'available'
		then
			insert into booking(bid,pid,ticketid,seat_num,seat_type,booking_status,location)
				values ((select max(bid)+1 from booking), pid, tktid, 
						(select max(seat_num)+1 from booking), stype, 'Booked', location);
			commit;
			
			/*
			cnt := cnt -1 ;
			if cnt = 0
			then update ticket set status_ = 'unavailable' where ticketid = tktid;	
			else update ticket set count_ = cnt where ticketid = tktid;
			end if;
			
			*/
		return 'Ticket Booked';
	else
		return 'Ticket unavailable';
	end if;
		
end;
/

-- add Train 

create or replace function addTrain(tname in varchar2, source in varchar2, destination in varchar2, seats in number)
	return varchar2
	is
--tid number;
begin
	insert into train(tid, tname, source, destination, seats)
		values((select max(tid)+1 from train) ,tname,  source, destination, seats);
	commit;
	return 'Train added';
end;
/

--cancel Booking 

create or replace function cancelTicket(bkingid in number)
	return varchar2
	is
	
tkt_status varchar2(30);
cnt number;
begin
	--select status_,count_ into tkt_status,cnt from ticket where ticketid = tktid; 
	update booking set booking_status = 'Canceled' where bid = bkingid;
	cnt := cnt + 1 ;
	update ticket set count_ = cnt where ticketid in (select ticketid from booking where bid = bkingid) ;
	commit;
	return 'Canceled';
end;
/