clear screen;

delete troute;
delete booking;
delete ticket;
delete passenger;
delete station;
delete train;



