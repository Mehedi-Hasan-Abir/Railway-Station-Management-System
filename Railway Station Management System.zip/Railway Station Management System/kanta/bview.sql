create or replace view 
	bookrview as select * from station;
	