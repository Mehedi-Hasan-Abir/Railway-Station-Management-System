create or replace view 
	stationview as select * from station;
	