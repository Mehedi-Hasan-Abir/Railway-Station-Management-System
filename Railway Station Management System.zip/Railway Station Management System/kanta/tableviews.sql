create or replace view 
	trainview as select * from train;