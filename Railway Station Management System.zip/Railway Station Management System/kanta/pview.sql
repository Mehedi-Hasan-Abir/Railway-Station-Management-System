create or replace view 
	psngrview as select * from station;
	