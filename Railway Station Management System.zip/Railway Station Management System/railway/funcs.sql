--ticket fare of a train 
create or replace procedure findFareofTrain(trname in varchar2)
	is

f number;
n varchar2(30);
cursor curr(trname varchar2) 
	is 	select tname , fare
	from train join ticket
	on train.tid = ticket.tid 
	where train.tname = trname;
begin 
	open curr(trname);
	loop
		fetch curr into n, f;
		exit when curr%notfound;
		dbms_output.put_line(n || '    ' || f);
	end loop;
	close curr;
end;
/

--add booking 
create or replace procedure addBooking(pname in passenger.pname%type, 
		gender in passenger.gender%type, 
		age in passenger.age%type, 
		city in passenger.city%type,
		source in ticket.source%type, 
		destination in ticket.dest%type,
		count_ in ticket.count_%type)
	is
ticketid ticket.ticketid%type;
tid ticket.tid%type;
fare ticket.fare%type;
dptime ticket.departure_time%type;
c_pid passenger.pid%type;
found number :=0;

cursor curr(s varchar2, d varchar2, c number)
	is select ticketid, tid, fare, departure_time from ticket
		where (source=s and dest=d and count_>=c);

begin 
	insert into passenger(pid, pname, gender, age, city)
	values((select max(pid)+1 from passenger), pname, gender, age, city);
	
	commit;
		open curr(source, destination, count_);
	
	loop
		fetch curr into ticketid, tid, fare, dptime;		
		exit when curr%notfound;
		
		if found = 0
			then 
			dbms_output.put_line('Ticketid		' || 'TrainId		' || 'Fare		' || 'Time   ');
			found :=1;
		end if;
		
		dbms_output.put_line(ticketid || '			' || tid || '		' || fare ||'	   ' || dptime);
	end loop;
	
	close curr;
	
	if found =0
		then dbms_output.put_line('Ticket unavailable.');

	end if;

	if found = 1 
		then 
			insert into booking(bid,pid,ticketid,seat_num,seat_type,booking_status,location)
			values((select max(bid) from booking),(select max(pid) from passenger),ticketid,15,'Shuvon','On','Kamlapur');
			DBMS_OUTPUT.PUT_LINE('Booked');
	commit;
	end if;
	--addPassenger(pname, gender, age, city);
	--findTicket(src,des,count_);
end;
/

---------------------------------------------------------------------------
/*
create or replace procedure addBooking2(pname in passenger.pname%type, 
		gender in passenger.gender%type, 
		age in passenger.age%type, 
		city in passenger.city%type,
		source in ticket.source%type, 
		destination in ticket.dest%type,
		count_ in ticket.count_%type)
	is

begin 
	dbms_output.put_line(msg);
	--addPassenger(pname, gender, age, city);
	--findTicket(src,des,count_);
end;
*/
